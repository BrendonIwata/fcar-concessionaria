package iwata.brendon.fcarconfigserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FcarConfigserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
