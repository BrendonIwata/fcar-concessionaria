package iwata.brendon.fcareurekaserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FcarEurekaserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
