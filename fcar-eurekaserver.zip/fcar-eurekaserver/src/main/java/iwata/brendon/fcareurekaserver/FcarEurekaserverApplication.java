package iwata.brendon.fcareurekaserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FcarEurekaserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(FcarEurekaserverApplication.class, args);
	}

}
