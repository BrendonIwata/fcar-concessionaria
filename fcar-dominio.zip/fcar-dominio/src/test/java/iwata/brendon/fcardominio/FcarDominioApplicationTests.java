package iwata.brendon.fcardominio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FcarDominioApplicationTests {

	@Test
	void contextLoads() {
	}

}
