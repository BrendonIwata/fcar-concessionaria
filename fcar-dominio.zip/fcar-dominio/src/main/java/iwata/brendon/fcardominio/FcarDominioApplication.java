package iwata.brendon.fcardominio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FcarDominioApplication {

	public static void main(String[] args) {
		SpringApplication.run(FcarDominioApplication.class, args);
	}

}
