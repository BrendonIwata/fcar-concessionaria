package iwata.brendon.fcarpedido;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FcarPedidoApplication {

	public static void main(String[] args) {
		SpringApplication.run(FcarPedidoApplication.class, args);
	}

}
